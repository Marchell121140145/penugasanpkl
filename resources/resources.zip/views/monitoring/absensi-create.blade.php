<x-admin-layout>
    <!-- Header -->
    <div class="flex items-center gap-4 mb-8">
        <a href="{{ route('absensi') }}" class="w-10 h-10 bg-white rounded-full flex items-center justify-center text-slate-500 hover:text-red-600 hover:-translate-x-1 hover:shadow-md transition-all shadow-sm">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
        </a>
        <div>
            <h1 class="text-slate-800 text-3xl font-bold mb-1">Buat Sesi Absensi</h1>
            <p class="text-slate-600">Buat absensi dan tugaskan kepada divisi atau pelaksana</p>
        </div>
    </div>

    @if ($errors->any())
        <div class="mb-6 p-4 rounded-xl list-none bg-red-50 border-l-4 border-red-500 text-red-700 shadow-sm">
            <div class="font-bold mb-2">Terjadi kesalahan:</div>
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
        <form action="{{ route('absensi.store') }}" method="POST">
            @csrf

            <!-- Informasi Utama -->
            <div class="mb-8">
                <h3 class="text-lg font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <span class="text-red-500">1</span> Informasi Absensi
                </h3>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="col-span-2">
                        <label for="title" class="block text-sm font-semibold text-slate-700 mb-2">Judul Absensi <span class="text-red-500">*</span></label>
                        <input type="text" name="title" id="title" class="w-full rounded-lg border-slate-300 focus:border-red-500 focus:ring focus:ring-red-200 transition-all shadow-sm bg-slate-50 p-2.5" placeholder="Contoh: Absen Pagi - 25 April" value="{{ old('title') }}" required>
                    </div>

                    <div class="col-span-2 md:col-span-1">
                        <label for="deadline" class="block text-sm font-semibold text-slate-700 mb-2">Batas Waktu Check-In (Deadline) <span class="text-red-500">*</span></label>
                        <input type="datetime-local" name="deadline" id="deadline" class="w-full rounded-lg border-slate-300 focus:border-red-500 focus:ring focus:ring-red-200 transition-all shadow-sm bg-slate-50 p-2.5" value="{{ old('deadline') }}" required>
                    </div>

                    <div class="col-span-2 md:col-span-1">
                        <label for="checkout_start" class="block text-sm font-semibold text-slate-700 mb-2">Waktu Mulai Check-Out</label>
                        <input type="datetime-local" name="checkout_start" id="checkout_start" class="w-full rounded-lg border-slate-300 focus:border-red-500 focus:ring focus:ring-red-200 transition-all shadow-sm bg-slate-50 p-2.5" value="{{ old('checkout_start') }}">
                        <p class="text-xs text-slate-500 mt-1">Pelaksana bisa check-out setelah waktu ini. Kosongkan jika bisa check-out kapan saja setelah check-in.</p>
                    </div>

                    <div class="col-span-2">
                        <label for="description" class="block text-sm font-semibold text-slate-700 mb-2">Deskripsi Keterangan</label>
                        <textarea name="description" id="description" rows="3" class="w-full rounded-lg border-slate-300 focus:border-red-500 focus:ring focus:ring-red-200 transition-all shadow-sm bg-slate-50 p-2.5" placeholder="Instruksi tambahan absensi...">{{ old('description') }}</textarea>
                    </div>
                </div>
            </div>

            <!-- Penugasan -->
            <div class="mb-8">
                <h3 class="text-lg font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <span class="text-red-500">2</span> Penugasan Absensi
                </h3>

                <div class="mb-6">
                    <label class="block text-sm font-semibold text-slate-700 mb-3">Tugaskan kepada <span class="text-red-500">*</span></label>
                    <div class="flex gap-6">
                        <label class="relative flex items-center p-3 rounded-xl border-2 border-slate-200 cursor-pointer hover:bg-slate-50 transition-all group has-[:checked]:border-red-500 has-[:checked]:bg-red-50/50">
                            <input type="radio" name="assign_type" value="divisi" class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 focus:ring-red-500" {{ old('assign_type') == 'divisi' ? 'checked' : '' }} onchange="toggleAssignType('divisi')">
                            <span class="ml-3 font-medium text-slate-700 group-has-[:checked]:text-red-700">Divisi (Semua Anggota)</span>
                        </label>
                        <label class="relative flex items-center p-3 rounded-xl border-2 border-slate-200 cursor-pointer hover:bg-slate-50 transition-all group has-[:checked]:border-red-500 has-[:checked]:bg-red-50/50">
                            <input type="radio" name="assign_type" value="pelaksana" class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 focus:ring-red-500" {{ old('assign_type', 'pelaksana') == 'pelaksana' ? 'checked' : '' }} onchange="toggleAssignType('pelaksana')">
                            <span class="ml-3 font-medium text-slate-700 group-has-[:checked]:text-red-700">Pelaksana Tertentu</span>
                        </label>
                    </div>
                </div>

                <!-- Divisi Selection -->
                <div id="divisi-selection" class="mb-6 hidden">
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Pilih Divisi <span class="text-red-500">*</span></label>
                    <p class="text-xs text-slate-500 mb-3">Pilih satu atau lebih divisi. Semua akun ber-role Pelaksana dari divisi terpilih akan ditugaskan.</p>
                    <div class="mb-3">
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                                <i class="fi fi-rr-search"></i>
                            </span>
                            <input type="text" id="searchDivisi" class="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-red-500 text-sm" placeholder="Cari divisi...">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[300px] overflow-y-auto p-4 bg-slate-50 border border-slate-200 rounded-xl" id="divisiContainer">
                        @foreach($divisis as $divisi)
                            <label class="flex items-center p-3 rounded-lg border border-slate-200 bg-white cursor-pointer hover:bg-red-50 transition-colors">
                                <input type="checkbox" name="divisi_ids[]" value="{{ $divisi->id }}" class="w-4 h-4 text-red-600 rounded focus:ring-red-500 mr-3" {{ (is_array(old('divisi_ids')) && in_array($divisi->id, old('divisi_ids'))) ? 'checked' : '' }}>
                                <span class="font-medium text-slate-700 divisi-name">{{ $divisi->nama }}</span>
                            </label>
                        @endforeach
                    </div>
                </div>

                <!-- Pelaksana Selection -->
                <div id="pelaksana-selection" class="mb-6 hidden">
                    <label class="block text-sm font-semibold text-slate-700 mb-2">Pilih Pelaksana <span class="text-red-500">*</span></label>
                    <p class="text-xs text-slate-500 mb-3">Pilih satu atau lebih mahasiswa/pelaksana.</p>
                    <div class="mb-3">
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                                <i class="fi fi-rr-search"></i>
                            </span>
                            <input type="text" id="searchPelaksana" class="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-red-500 text-sm" placeholder="Cari nama atau divisi pelaksana...">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[400px] overflow-y-auto p-4 bg-slate-50 border border-slate-200 rounded-xl" id="pelaksanaContainer">
                        @foreach($pelaksanas as $pelaksana)
                            <label class="flex items-center p-3 rounded-lg border border-slate-200 bg-white cursor-pointer hover:bg-red-50 transition-colors">
                                <input type="checkbox" name="pelaksana_ids[]" value="{{ $pelaksana->id }}" class="w-4 h-4 text-red-600 rounded focus:ring-red-500 mr-3" {{ (is_array(old('pelaksana_ids')) && in_array($pelaksana->id, old('pelaksana_ids'))) ? 'checked' : '' }}>
                                <div class="flex items-center gap-3">
                                    <div class="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center text-red-600 font-bold overflow-hidden flex-shrink-0">
                                        @if($pelaksana->avatar)
                                            <img src="{{ route('file.avatar', $pelaksana->id) }}" alt="{{ $pelaksana->name }}" class="w-full h-full object-cover">
                                        @else
                                            {{ substr($pelaksana->name, 0, 1) }}
                                        @endif
                                    </div>
                                    <div class="overflow-hidden">
                                        <div class="font-medium text-slate-800 text-sm truncate pelaksana-name">{{ $pelaksana->name }}</div>
                                        <div class="text-xs text-slate-500 truncate pelaksana-divisi">{{ $pelaksana->divisi?->nama ?? 'Tanpa Divisi' }}</div>
                                    </div>
                                </div>
                            </label>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="flex justify-end gap-3 pt-6 border-t border-slate-100">
                <a href="{{ route('absensi') }}" class="px-6 py-2.5 border-2 border-slate-200 text-slate-700 font-medium rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-colors">Batal</a>
                <button type="submit" class="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-medium rounded-xl shadow-sm hover:shadow transition-all flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    Buat Absensi
                </button>
            </div>
        </form>
    </div>

    <script>
        function toggleAssignType(type) {
            const divisiSection = document.getElementById('divisi-selection');
            const pelaksanaSection = document.getElementById('pelaksana-selection');

            if (type === 'divisi') {
                divisiSection.classList.remove('hidden');
                pelaksanaSection.classList.add('hidden');
            } else {
                divisiSection.classList.add('hidden');
                pelaksanaSection.classList.remove('hidden');
            }
        }

        // Initialize display based on current selection
        document.addEventListener('DOMContentLoaded', function() {
            const checkedRadio = document.querySelector('input[name="assign_type"]:checked');
            if (checkedRadio) {
                toggleAssignType(checkedRadio.value);
            } else {
                toggleAssignType('pelaksana'); // Default
            }

            // Search Filter for Divisi
            const searchDivisiInput = document.getElementById('searchDivisi');
            if (searchDivisiInput) {
                searchDivisiInput.addEventListener('input', function() {
                    const filter = this.value.toLowerCase();
                    const labels = document.querySelectorAll('#divisiContainer label');
                    labels.forEach(label => {
                        const name = label.querySelector('.divisi-name').textContent.toLowerCase();
                        if (name.includes(filter)) {
                            label.style.display = 'flex';
                        } else {
                            label.style.display = 'none';
                        }
                    });
                });
            }

            // Search Filter for Pelaksana
            const searchPelaksanaInput = document.getElementById('searchPelaksana');
            if (searchPelaksanaInput) {
                searchPelaksanaInput.addEventListener('input', function() {
                    const filter = this.value.toLowerCase();
                    const labels = document.querySelectorAll('#pelaksanaContainer label');
                    labels.forEach(label => {
                        const name = label.querySelector('.pelaksana-name').textContent.toLowerCase();
                        const divisi = label.querySelector('.pelaksana-divisi').textContent.toLowerCase();
                        if (name.includes(filter) || divisi.includes(filter)) {
                            label.style.display = 'flex';
                        } else {
                            label.style.display = 'none';
                        }
                    });
                });
            }
        });
    </script>
</x-admin-layout>


